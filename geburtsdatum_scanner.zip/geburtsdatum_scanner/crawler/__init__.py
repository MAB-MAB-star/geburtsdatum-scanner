# Geburtsdatum-Pflichtfeld-Scanner
